import FrameWork.*;
import Entities.*;
import java.lang.*;

public class Start
{
	public static void main(String[] args)
	{
		Continue c1=new Continue();
		c1.setVisible(true);
		
	}
}