package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Doctor extends JFrame implements MouseListener,ActionListener
{
	
	JLabel label;
	JPanel panel;
	Color labelcolor,btncolor,backbtncolor;
	Font labelfont,btnfont;
	JButton ronbtn,messibtn,jrbtn,ardabtn,lordbtn,backbtn;
	
	
	public Doctor()
	{
		
		super("Doctor's appointment management system");
		this.setSize(600,600);
		this.setLocation(400,50);
		this.setResizable(false);
		
		//colors
		labelcolor= new Color(221,224,217);
		btncolor= new Color(79,207,68);
		backbtncolor= new Color(209,48,48);
		
		//fonts
		labelfont= new Font("Century Gothic", Font.BOLD, 25);
		btnfont= new Font("Times New Roman", Font.PLAIN, 20);
		
		panel= new JPanel();
		panel.setLayout(null);
		panel.setBackground(labelcolor);
		
		
		//label
		label=new JLabel("TAP TO VIEW FULL DETAILS ");
		label.setBounds(140,35,330,40);
		label.setBackground(labelcolor);
		label.setOpaque(true);
		label.setFont(labelfont);
		label.setForeground(Color.BLACK);
		panel.add(label);
		
		//button
		ronbtn= new JButton ("PROF. DR. Cristiano Ronaldo");
		ronbtn.setBounds(130,130,320,40);
		ronbtn.setBackground(btncolor);
		ronbtn.setFont(btnfont);
		ronbtn.setForeground(Color.BLACK);
		ronbtn.addMouseListener(this);
		ronbtn.addActionListener(this);
		panel.add(ronbtn);
		
		
		messibtn= new JButton ("PROF. DR. Lionel Messi");
		messibtn.setBounds(130,190,320,40);
		messibtn.setBackground(btncolor);
		messibtn.setFont(btnfont);
		messibtn.setForeground(Color.BLACK);
		messibtn.addMouseListener(this);
		messibtn.addActionListener(this);
		panel.add(messibtn);
		
		
		jrbtn= new JButton ("DR. Neymar Jr.");
		jrbtn.setBounds(130,250,320,40);
		jrbtn.setBackground(btncolor);
		jrbtn.setFont(btnfont);
		jrbtn.setForeground(Color.BLACK);
		jrbtn.addMouseListener(this);
		jrbtn.addActionListener(this);
		panel.add(jrbtn);
		
		ardabtn= new JButton ("DR. Arda Guler");
		ardabtn.setBounds(130,310,320,40);
		ardabtn.setBackground(btncolor);
		ardabtn.setFont(btnfont);
		ardabtn.setForeground(Color.BLACK);
		ardabtn.addMouseListener(this);
		ardabtn.addActionListener(this);
		panel.add(ardabtn);
		
		lordbtn= new JButton ("DR. Harry Meguire");
		lordbtn.setBounds(130,360,320,40);
		lordbtn.setBackground(btncolor);
		lordbtn.setFont(btnfont);
		lordbtn.setForeground(Color.BLACK);
		lordbtn.addMouseListener(this);
		lordbtn.addActionListener(this);
		panel.add(lordbtn);
		
		backbtn= new JButton ("BACK");
		backbtn.setBounds(250,440,100,40);
		backbtn.setBackground(backbtncolor);
		backbtn.setFont(btnfont);
		backbtn.setForeground(Color.BLACK);
		backbtn.addMouseListener(this);
		backbtn.addActionListener(this);
		panel.add(backbtn);
		
		
		
		this.add(panel);		
	}
	
	
	//mouseListener
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseClicked(MouseEvent me)
	{
		if(me.getSource()==ronbtn)
		{
			ronbtn.setBackground(Color.WHITE);
			ronbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==messibtn)
		{
			messibtn.setBackground(Color.WHITE);
			messibtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==jrbtn)
		{
			jrbtn.setBackground(Color.WHITE);
			jrbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==ardabtn)
		{
			ardabtn.setBackground(Color.WHITE);
			ardabtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==lordbtn)
		{
			lordbtn.setBackground(Color.WHITE);
			lordbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtn)
		{
			lordbtn.setBackground(Color.WHITE);
			lordbtn.setForeground(Color.BLACK);
		}
		
	}

	
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==ronbtn)
		{
			ronbtn.setBackground(btncolor);
			ronbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==messibtn)
		{
			messibtn.setBackground(btncolor);
			messibtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==jrbtn)
		{
			jrbtn.setBackground(btncolor);
			jrbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==ardabtn)
		{
			jrbtn.setBackground(btncolor);
			jrbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==lordbtn)
		{
			lordbtn.setBackground(btncolor);
			lordbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtn)
		{
			backbtn.setBackground(backbtncolor);
			backbtn.setForeground(Color.BLACK);
		}

	}
	
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==ronbtn)
		{
			ronbtn.setBackground(btncolor);
			ronbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==messibtn)
		{
			messibtn.setBackground(btncolor);
			messibtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==jrbtn)
		{
			jrbtn.setBackground(btncolor);
			jrbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==ardabtn)
		{
			ardabtn.setBackground(btncolor);
			ardabtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==lordbtn)
		{
			lordbtn.setBackground(btncolor);
			lordbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtncolor)
		{
			lordbtn.setBackground(backbtncolor);
			lordbtn.setForeground(Color.BLACK);
		}
		
	}

	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==ronbtn){
			Ronaldo cr1 = new Ronaldo();
			cr1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==messibtn){
			
			Messi ms1 = new Messi();
			ms1.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==jrbtn){
			
			Neymar nr1 = new Neymar();
			nr1.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==ardabtn){
			
			Guler gr1 = new Guler();
			gr1.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==lordbtn){
			
			Meguire mg1 = new Meguire();
			mg1.setVisible(true);
			this.setVisible(false);
			
		}

		
		else if(ae.getSource()==backbtn){
			Dashboard d3 = new Dashboard();
			d3.setVisible(true);
			this.setVisible(false);
		}
	}
}