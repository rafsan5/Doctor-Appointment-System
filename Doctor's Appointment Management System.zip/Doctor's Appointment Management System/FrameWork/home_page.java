package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class home_page extends JFrame implements MouseListener,ActionListener{
	
	
	public JPanel panel;
	public Color mycolor,mycolor1,mycolor2,mycolor3;
	public Font myfont,myfont2;
	public JLabel Welclbl,imagelbl;
	
	public JButton Docbtn,Makeappbtn,backbtn;
	
	public ImageIcon img;
	
	public home_page(){
		
		super("Doctor's appointment system - Home page window");
		this.setSize(900,600);
		this.setLocation(200,50);
		//this.setResizable(false);
		
		img=new ImageIcon("./Images/hmpg.jpg");
		
		panel=new JPanel();
		panel.setLayout(null);
		
		
		
		mycolor= new Color(157,200,212);
		mycolor1=new Color(61,191,180);//blue
		mycolor2=new Color(79,207,68);//green
		mycolor3 = new Color(209,48,48);//red
		
		
		myfont=new Font("Times New Roman", Font.PLAIN, 20);
		myfont2= new Font("Century Gothic", Font.BOLD, 30);
		
		panel.setBackground(mycolor);
		
		Welclbl=new JLabel("WELCOME TO DOCTOR'S APPOINTMENT SYSTEM");
		Welclbl.setBounds(100,50,900,50);
		Welclbl.setFont(myfont2);
		Welclbl.setForeground(Color.BLACK);
		panel.add(Welclbl);
		
		Docbtn=new JButton("DOCTORS' LIST");
		Docbtn.setBounds(150,250,260,40);
		Docbtn.setFont(myfont);
		Docbtn.setBackground(mycolor1);
		Docbtn.setForeground(Color.BLACK);
		Docbtn.addMouseListener(this);
		Docbtn.addActionListener(this);
		panel.add(Docbtn);
		
		Makeappbtn=new JButton("MAKE APPOINTMENT");
		Makeappbtn.setBounds(470,250,260,40);
		Makeappbtn.setFont(myfont);
		Makeappbtn.setBackground(mycolor2);
		Makeappbtn.setForeground(Color.BLACK);
		Makeappbtn.addActionListener(this);
		Makeappbtn.addMouseListener(this);
		panel.add(Makeappbtn);
		
		backbtn=new JButton("BACK");
		backbtn.setBounds(390,330,100,40);
		backbtn.setFont(myfont);
		backbtn.setBackground(mycolor3);
		backbtn.setForeground(Color.BLACK);
		backbtn.addActionListener(this);
		backbtn.addMouseListener(this);
		panel.add(backbtn);
		
		imagelbl=new JLabel(img);
		imagelbl.setBounds(0,0,1000,700);
		panel.add(imagelbl);
		
		this.add(panel);	
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if (me.getSource()==Docbtn){
			Docbtn.setBackground(mycolor1);
			Docbtn.setForeground(Color.BLACK);
		}
		else if (me.getSource()==Makeappbtn){
			Makeappbtn.setBackground(mycolor2);
			Makeappbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtn)
		{
		backbtn.setBackground(mycolor3);
		backbtn.setForeground(Color.BLACK);
		}
	}
    public void mouseExited(MouseEvent me){
	if(me.getSource()==Docbtn){
		Docbtn.setBackground(mycolor1);
		Docbtn.setForeground(Color.BLACK);
	}
	else if(me.getSource()==Makeappbtn){
		Makeappbtn.setBackground(mycolor2);
		Makeappbtn.setForeground(Color.BLACK);
	}
	else if(me.getSource()==backbtn){
		backbtn.setBackground(mycolor3);
		backbtn.setForeground(Color.BLACK);
	}

	}
	
	
	//actionListener
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==Docbtn){
			Dashboard d1 = new Dashboard();
			d1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==Makeappbtn){
			
			Appointment ap = new Appointment();
			ap.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==backbtn){
			Login l2 = new Login();
			l2.setVisible(true);
			this.setVisible(false);
		}
	}
}