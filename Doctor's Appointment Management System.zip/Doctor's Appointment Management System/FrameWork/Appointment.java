package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Appointment extends JFrame implements MouseListener, ActionListener{
	
	public JPanel panel;
	public Color mycolor,mycolor1,mycolor2,mycolor3;
	public Font myfont,myfont2;
	public JLabel Makeappointlbl;
	public JButton Donebtn,Cancelbtn;
	public ImageIcon img;
	public JComboBox<String> combobox,combobox1;
	
	public Appointment(){
		
		super("Doctor's appointment management system - Management window");
		this.setSize(900,650);
		this.setLocation(200,50);
		
		//img=new ImageIcon(".\nnn.jpeg");
		
		panel=new JPanel();
		panel.setLayout(null);
		
		mycolor= new Color(221,224,217);//background
		mycolor1=new Color(61,191,180);//blue
		mycolor2=new Color(79,207,68);//green
		mycolor3 = new Color(209,48,48);//red
		
		myfont=new Font("Times New Roman", Font.BOLD, 20);
		myfont2= new Font("Century Gothic", Font.BOLD, 30);
		
		panel.setBackground(mycolor);
		
		Makeappointlbl=new JLabel("MAKE APPOINTMENT");
		Makeappointlbl.setBounds(300,60,300,50);
		Makeappointlbl.setOpaque(true);
		Makeappointlbl.setFont(myfont2);
		Makeappointlbl.setBackground(mycolor);
		Makeappointlbl.setForeground(Color.BLACK);
		panel.add(Makeappointlbl);
		
		
		Donebtn=new JButton("DONE");
		Donebtn.setBounds(250,400,150,50);
		Donebtn.setFont(myfont);
		Donebtn.setBackground(mycolor2);
		Donebtn.addMouseListener(this);
		Donebtn.addActionListener(this);
		panel.add(Donebtn);
		
		Cancelbtn=new JButton("CANCEL");
		Cancelbtn.setBounds(500,400,150,50);
		Cancelbtn.setFont(myfont);
		Cancelbtn.setBackground(mycolor3);
		Cancelbtn.addMouseListener(this);
		Cancelbtn.addActionListener(this);
        panel.add(Cancelbtn);
		
		/*imglbl=new JLabel(img);
		imglbl.setBounds(0,0,700,600);
		panel.add(imglbl);*/
		
		String[] doctors={"Prof.Dr.Cristiano Ronaldo","Dr.Lionel Messi","Dr.Neymar Jr","DR. Arda Guler","Dr.Harry Meguire"};
		String[] time={"8:00am-9:00pm","9:00am-10:00am","10:00am-11:00am","11:00am-12:00pm","12:00pm-1:00pm","4:00-5:00","5:00pm-6:00pm"};
		
	    combobox= new JComboBox(doctors);
		combobox1=new JComboBox(time);

		combobox.setBounds(150,200,200,30);
		combobox1.setBounds(540,200,200,30);

		combobox.addActionListener(this);
		combobox1.addActionListener(this);

		panel.add(combobox1);
		panel.add(combobox);

		
		this.add(panel);
		this.setVisible(true);
	}
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==Donebtn){
			Donebtn.setBackground(Color.GRAY);
			Donebtn.setForeground(Color.RED);
		}
		else if(me.getSource()==Cancelbtn){
			Cancelbtn.setBackground(Color.GRAY);
			Cancelbtn.setForeground(Color.RED);
		}
	}
		
		public void mouseExited(MouseEvent me){
			if(me.getSource()==Donebtn){
			Donebtn.setBackground(mycolor2);
			Donebtn.setForeground(Color.BLACK);
			}
			else if(me.getSource()==Cancelbtn){
				Cancelbtn.setBackground(mycolor3);
				Cancelbtn.setForeground(Color.BLACK);
				
			}
		}
		
		public void actionPerformed(ActionEvent ae){
			if(ae.getSource()==Donebtn){
				ConfirmAppoint cap = new ConfirmAppoint();
				cap.setVisible(true);
				this.setVisible(false);
			}
			else if(ae.getSource()==Cancelbtn){
				Dashboard d2 = new Dashboard();
				d2.setVisible(true);
				this.setVisible(false);
			}
			else if(ae.getSource()==combobox){
				System.out.println(combobox.getSelectedItem());
			}
			else if(ae.getSource()==combobox1){
				System.out.println(combobox1.getSelectedItem());
			}
			
			}
		
		}
		
