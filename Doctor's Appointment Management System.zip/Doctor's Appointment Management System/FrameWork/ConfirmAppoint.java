package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class ConfirmAppoint extends JFrame implements MouseListener, ActionListener
{
	
	public JPanel panel;
	public Color greencolor,redcolor;
	public Font  labelfont,btnfont;
	public JLabel Confrmappointlbl, imglbl;
	
	ImageIcon img;
	
	public JButton backbtn,exitbtn;
	
	public ConfirmAppoint(){
		
		super("Doctor appointment system - Confirmation window");
		this.setSize(900,600);
		this.setLocation(200,50);
		this.setResizable(false);
		
		
		panel =new JPanel();
		panel.setLayout(null);
		
		
		img= new ImageIcon("./Images/app.jpg");
		
		//color
		greencolor= new Color(30,145,57);
		redcolor=new Color(201,2,6);
		
		//font
		labelfont= new Font("Century Gothic", Font.BOLD, 30);
		btnfont=new Font("Times New Roman",Font.BOLD,25);
		
		panel.setBackground(Color.WHITE);
		
		
		//label
		Confrmappointlbl=new JLabel("YOUR APPOINTMENT IS CONFIRMED");
		Confrmappointlbl.setBounds(180,0,600,50);
		Confrmappointlbl.setOpaque(true);
		Confrmappointlbl.setFont(labelfont);
		Confrmappointlbl.setBackground(Color.WHITE);
		Confrmappointlbl.setForeground(Color.BLACK);
		panel.add(Confrmappointlbl);
		

		//button
		backbtn=new JButton("BACK");
		backbtn.setBounds(100,450,120,50);
		backbtn.setFont(btnfont);
		backbtn.setBackground(greencolor);
		backbtn.setForeground(Color.BLACK);
		backbtn.addActionListener(this);
		backbtn.addMouseListener(this);
		panel.add(backbtn);
		
		exitbtn=new JButton("EXIT");
		exitbtn.setBounds(700,450,120,50);
		exitbtn.setFont(btnfont);
		exitbtn.setBackground(redcolor);
		exitbtn.setForeground(Color.BLACK);
		exitbtn.addActionListener(this);
		exitbtn.addMouseListener(this);
		panel.add(exitbtn);
		
		
		//img
		imglbl=new JLabel(img);
		imglbl.setBounds(0,11,900,600);
		panel.add(imglbl);
		
		
		this.add(panel);
	}
    
	
	//mouseListener
	
	
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseClicked(MouseEvent me)
	{
		if(me.getSource()==backbtn)
		{
			backbtn.setBackground(Color.WHITE);
			backbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==exitbtn)
		{
			exitbtn.setBackground(Color.WHITE);
			exitbtn.setForeground(Color.BLACK);
		}
	}
	
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==backbtn)
		{
			backbtn.setBackground(greencolor);
			backbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==exitbtn)
		{
			exitbtn.setBackground(redcolor);
			exitbtn.setForeground(Color.BLACK);
		}

	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==backbtn)
		{
			backbtn.setBackground(greencolor);
			backbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==exitbtn)
		{
			exitbtn.setBackground(redcolor);
			exitbtn.setForeground(Color.BLACK);
		}
		
	}
	
	//actionListener
	
	public void actionPerformed(ActionEvent ae)
	 {
		 if(ae.getSource()==backbtn){
			 Appointment ap2 = new Appointment();
			 ap2.setVisible(true);
			 this.setVisible(false);
		 }
		 else if(ae.getSource()==exitbtn){
			System.exit(0);
		 }
	 }
	 
	 
	
}