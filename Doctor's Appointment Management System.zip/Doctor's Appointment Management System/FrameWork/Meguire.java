package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Meguire extends JFrame implements MouseListener,ActionListener
{
	
	JLabel nlabel,slabel,dlabel,imglabel;
	JPanel panel;
	Color ncolor,sdcolor,getcolor,backbtncolor;
	Font nfont,sdfont,btnfont;
	JButton getbtn, backbtn;
	ImageIcon img;
	
	public Meguire()
	{
		super("Doctor Appointment Management System - Details Window");
		this.setSize(600,600);
		this.setLocation(400,50);
		this.setResizable(false);
		
		
		//colors
		ncolor= new Color(212,22,22);
		sdcolor= new Color(0,0,0);
		getcolor= new Color(79,207,68);
		backbtncolor= new Color(209,48,48);
		
		//font
		nfont= new Font("Bodoni MT Black",Font.PLAIN+Font.BOLD,20);
		sdfont= new Font("Times New Roman", Font.PLAIN,17);
		btnfont= new Font("Times New Roman", Font.PLAIN, 20);
		
		img= new ImageIcon("./Images/Harry.jpg");
		
		panel= new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(221,224,217));
		
		
		//label
		nlabel= new JLabel("DR. Harry Meguire");
		nlabel.setBounds(200,250,340,40);
		nlabel.setBackground(new Color(221,224,217));
		nlabel.setOpaque(true);
		nlabel.setFont(nfont);
		nlabel.setForeground(Color.BLACK);
		panel.add(nlabel);
		
		
		slabel= new JLabel(">>Specialty -Senior Consultant, Psychiatry");
		slabel.setBounds(10,320,600,30);
		slabel.setBackground(new Color(221,224,217));
		slabel.setOpaque(true);
		slabel.setFont(sdfont);
		slabel.setForeground(Color.BLACK);
		panel.add(slabel);
		
		dlabel= new JLabel(">>Degree - MBBS,FCPS,FRCP(UK),FACP(USA)");
		dlabel.setBounds(10,370,600,30);
		dlabel.setBackground(new Color(221,224,217));
		dlabel.setOpaque(true);
		dlabel.setFont(sdfont);
		dlabel.setForeground(Color.BLACK);
		panel.add(dlabel);
		
		//button
		getbtn= new JButton ("GET APPOINTMENT");
		getbtn.setBounds(50,450,240,40);
		getbtn.setBackground(getcolor);
		getbtn.setFont(btnfont);
		getbtn.setForeground(Color.BLACK);
		getbtn.addMouseListener(this);
		getbtn.addActionListener(this);
		panel.add(getbtn);
		
		backbtn= new JButton ("BACK");
		backbtn.setBounds(320,450,240,40);
		backbtn.setBackground(backbtncolor);
		backbtn.setFont(btnfont);
		backbtn.setForeground(Color.BLACK);
		backbtn.addMouseListener(this);
		backbtn.addActionListener(this);
		panel.add(backbtn);
		
		
		
		
		imglabel=new JLabel(img);
		imglabel.setBounds(200,30,img.getIconWidth(),img.getIconHeight());
		panel.add(imglabel);
		
		
		this.add(panel);
		
	}
	
	
	//mouseListener
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseClicked(MouseEvent me)
	{
		if(me.getSource()==getbtn)
		{
			getbtn.setBackground(Color.WHITE);
			getbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtn)
		{
			backbtn.setBackground(Color.WHITE);
			backbtn.setForeground(Color.BLACK);
		}
	}

	
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==getbtn)
		{
			getbtn.setBackground(getcolor);
			getbtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtn)
		{
			backbtn.setBackground(backbtncolor);
			backbtn.setForeground(Color.BLACK);
		}

	}
	
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==getbtn)
		{
			getbtn.setBackground(getcolor);
			getbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==backbtn)
		{
			backbtn.setBackground(backbtncolor);
			backbtn.setForeground(Color.BLACK);
		}
		
	}
	
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==getbtn){
			Appointment a4 = new Appointment();
			a4.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==backbtn){
			Doctor dr1 = new Doctor();
			dr1.setVisible(true);
			this.setVisible(false);
		}
	}
	
}