package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Dashboard extends JFrame implements MouseListener,ActionListener
{
	JLabel label;
	JPanel panel;
	Color mycolor1,mycolor2,mycolor3,mycolor4;
	Font font,font2,font3,font4;
	JTable table;
	JScrollPane scroll;
	JButton morebtn,makebtn,backbtn;
	
	
	
	String[] cols = {"ID","NAME","DEPARTMENT","GENDER"};
	String[][] rows = {
						
						{"07","PROF. DR. Cristiano Ronaldo","Cardiology","Male"},
						{"10","PROF. DR. Lionel Messi", "Neurology","Male"},
						{"11","DR. Neymar Jr.","General Surgery","Male"},
						{"15","DR. Arda Guler","Child Development","Male"},
						{"05","DR. Harry Meguire", "Psychiatry","Male"},	
		
					};
	
	
	
	
	
	public Dashboard()
	{
		super("Doctor appointment system - Dashboard Window");
		this.setSize(900,600);
		this.setLocation(200,50);
		this.setResizable(false);
		
		//colors
		mycolor1= new Color(121,68,173);//purple
		mycolor2= new Color(79,207,68);//green
		mycolor3= new Color(209,48,48);//red
		mycolor4= new Color(221,224,217);//background
		
		//fonts
		font = new Font("Century", Font.BOLD, 32);
		font2= new Font("poppins", Font.PLAIN, 14);
		font3= new Font("poppins", Font.PLAIN, 18);
		font4= new Font("Arial Rounded MT Bold",Font.PLAIN,20);
		
		panel= new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor4);
		
		//label
		label=new JLabel("FIND A DOCTOR");
		label.setBounds(320,35,300,40);
		label.setBackground(mycolor4);
		label.setOpaque(true);
		label.setFont(font);
		label.setForeground(mycolor1);
		panel.add(label);
		
		
		//button
		morebtn= new JButton ("MORE DETAILS");
		morebtn.setBounds(350,350,190,40);
		morebtn.setBackground(mycolor1);
		morebtn.setFont(font4);
		morebtn.setForeground(Color.BLACK);
		morebtn.addMouseListener(this);
        morebtn.addActionListener(this);
		panel.add(morebtn);
		
		makebtn= new JButton ("MAKE APPOINTMENT");
		makebtn.setBounds(325,410,300,40);
		makebtn.setBackground(mycolor2);
		makebtn.setFont(font4);
		makebtn.setForeground(Color.BLACK);
		makebtn.addMouseListener(this);
		makebtn.addActionListener(this);
		panel.add(makebtn);
		
		backbtn= new JButton("BACK");
		backbtn.setBounds(770,500,100,40);
		backbtn.setBackground(mycolor3);
		backbtn.setFont(font4);
		backbtn.setForeground(Color.BLACK);
		backbtn.addMouseListener(this);
		backbtn.addActionListener(this);
		panel.add(backbtn);
		
		
		
		
		
		//table
		table= new JTable(rows,cols);
		table.setEnabled(false);
		table.setFont(font2);
		table.getTableHeader().setFont(font3);
		//table.setBounds(0,0,400,500);
		table.setRowHeight(35);
		table.setBackground(new Color(174,247,255));
		//table.setSelectionBackground(new Color(200, 200, 230));
		
		scroll= new JScrollPane(table);
		scroll.setBounds(50,120,800,200);
		panel.add(scroll);
		
		
		this.add(panel);
			
		
	}
	
	
	//mouseListener
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseClicked(MouseEvent me)
	{
		if(me.getSource()==morebtn)
		{
			morebtn.setBackground(Color.WHITE);
			morebtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==makebtn)
		{
			makebtn.setBackground(Color.WHITE);
			makebtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtn)
		{
			backbtn.setBackground(Color.WHITE);
			backbtn.setForeground(Color.BLACK);
		}
	}

	
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==morebtn)
		{
			morebtn.setBackground(mycolor1);
			morebtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==makebtn)
		{
			makebtn.setBackground(mycolor2);
			makebtn.setForeground(Color.BLACK);
		}
		else if(me.getSource()==backbtn)
		{
			backbtn.setBackground(mycolor3);
			backbtn.setForeground(Color.BLACK);
		}

	}
	
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==morebtn)
		{
			morebtn.setBackground(mycolor1);
			morebtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==makebtn)
		{
			makebtn.setBackground(mycolor2);
			makebtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==backbtn)
		{
			backbtn.setBackground(mycolor3);
			backbtn.setForeground(Color.BLACK);
		}
		
	}
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==morebtn){
			Doctor dr1 = new Doctor();
			dr1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==makebtn){
			
			Appointment ap1 = new Appointment();
			ap1.setVisible(true);
			this.setVisible(false);
			
		}
		else if(ae.getSource()==backbtn){
			home_page h3 = new home_page();
			h3.setVisible(true);
			this.setVisible(false);
		}
	}


}