package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Login extends JFrame implements MouseListener, ActionListener{
	public JPanel panel;
	public Font myfont,myfont2;
	public Color mycolor,lgnclr,regclr,bckclr;
	public JLabel title,limglbl, namelbl,passlbl;
	public JTextField namefld;
	public JPasswordField passfld;
	public JButton lgnbtn,regbtn,bckbtn;
	public ImageIcon limg;
	
	public Login(){
		super("Login Page");
		this.setSize(1020,620);
		this.setLocation(130,30);
		this.setResizable(false);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		lgnclr = new Color(61,191,180);
		regclr = new Color(79,207,68);
		bckclr = new Color(209,48,48);
		
		mycolor = new Color(221,224,217);
		
		myfont = new Font("Times New Roman",Font.PLAIN,25);
		//myfont2 = new Font("Times New Roman",Font.PLAIN+Font.BOLD,30);
	
		panel.setBackground(mycolor);
		
		title=new JLabel("LOGIN AS PATIENT");
		title.setBounds(120,30,280,100);
		title.setFont(myfont);
		panel.add(title);
		
		namelbl=new JLabel("Username:");
		namelbl.setBounds(50,170,180,40);
		namelbl.setFont(myfont);
		panel.add(namelbl);
		
		namefld=new JTextField();
		namefld.setBounds(200,170,180,40);
		panel.add(namefld);
		
		passlbl=new JLabel("Password:");
		passlbl.setBounds(50,250,180,40);
		passlbl.setFont(myfont);
		panel.add(passlbl);
		
		passfld=new JPasswordField();
		passfld.setBounds(200,250,180,40);
		passfld.setEchoChar('*');
		panel.add(passfld);
		
		lgnbtn=new JButton("LOGIN");
		lgnbtn.setBounds(50,400,150,40);
		lgnbtn.setBackground(lgnclr);
		lgnbtn.setFont(myfont);
		lgnbtn.setForeground(Color.WHITE);
		lgnbtn.addMouseListener(this);
		lgnbtn.addActionListener(this);
		panel.add(lgnbtn);
		
		regbtn=new JButton("REGISTER");
		regbtn.setBounds(230,400,200,40);
		regbtn.setBackground(regclr);
		regbtn.setFont(myfont);
		regbtn.setForeground(Color.WHITE);
		regbtn.addMouseListener(this);
		regbtn.addActionListener(this);
		panel.add(regbtn);
		
		
		bckbtn=new JButton("CLOSE");
		bckbtn.setBounds(150,480,120,40);
		bckbtn.setBackground(bckclr);
		bckbtn.setFont(myfont);
		bckbtn.setForeground(Color.WHITE);
		bckbtn.addMouseListener(this);
		bckbtn.addActionListener(this);
		panel.add(bckbtn);
		
		limg = new ImageIcon("./Images/lgn.jpg");
		limglbl=new JLabel(limg);
		limglbl.setBounds(320,0,950,700);
		panel.add(limglbl);
		
		this.add(panel);
		
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	public void actionPerformed(ActionEvent ae)
	{
		
		String s1 = namefld.getText();
		String s2 = new String(passfld.getPassword());
		
		Account a1 = new Account();
		
		if(ae.getSource()==lgnbtn)
		{
			if(a1.checkLogin(s1,s2)==true){
				JOptionPane.showMessageDialog(this,"Hello");
				
				home_page h1=new home_page();
				h1.setVisible(true);
				this.setVisible(false);
			}
			
			else
			{
				JOptionPane.showMessageDialog(this,"Username or Password Incorrect");
			}
		}
		else if(ae.getSource()==regbtn){
			Registration r1 = new Registration();
			r1.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==bckbtn)
		{
			System.exit(0);
		}
}

}