package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Continue extends JFrame implements MouseListener,ActionListener
{
	
	private JPanel panel;
	private Color greencolor,redcolor;
	private Font btnfont;
	private JLabel imglbl;
	private JButton conbtn,exitbnt;
	
	private ImageIcon img;
	
	
	public Continue()
	{
		super("Doctor appointment system - Continue window");
		this.setSize(900,600);
		this.setLocation(200,50);
		this.setResizable(false);
		
		panel=new JPanel();
		panel.setLayout(null);
		
		greencolor=new Color(79,207,68);
		redcolor=new Color(209,48,48);
		btnfont=new Font("Times New Roman",Font.PLAIN,25);
		
		img=new ImageIcon("./Images/conpage.jpg");
		
		panel.setBackground(Color.WHITE);
		
		conbtn=new JButton("CLICK HERE TO CONTINUE");
		conbtn.setBounds(60,420,400,35);
		conbtn.setFont(btnfont);
		conbtn.setBackground(greencolor);
		conbtn.addMouseListener(this);
		conbtn.addActionListener(this);
		panel.add(conbtn);
		
		exitbnt=new JButton("EXIT");
		exitbnt.setBounds(220,475,100,35);
		exitbnt.setFont(btnfont);
		exitbnt.setBackground(redcolor);
		exitbnt.addMouseListener(this);
		exitbnt.addActionListener(this);
		panel.add(exitbnt);
		
		
		imglbl=new JLabel(img);
		imglbl.setBounds(0,0,900,600);
		panel.add(imglbl);
		
		
		
		
		
		this.add(panel);
	}
	
	
	//mouseListener
	
	
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseClicked(MouseEvent me)
	{
		if(me.getSource()==conbtn)
		{
			conbtn.setBackground(Color.WHITE);
			conbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==exitbnt)
		{
			exitbnt.setBackground(Color.WHITE);
			exitbnt.setForeground(Color.BLACK);
		}
	}
	
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource()==conbtn)
		{
			conbtn.setBackground(greencolor);
			conbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==exitbnt)
		{
			exitbnt.setBackground(redcolor);
			exitbnt.setForeground(Color.BLACK);
		}

	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource()==conbtn)
		{
			conbtn.setBackground(greencolor);
			conbtn.setForeground(Color.BLACK);
		}
		
		else if(me.getSource()==exitbnt)
		{
			exitbnt.setBackground(redcolor);
			exitbnt.setForeground(Color.BLACK);
		}
		
	}
	
	public void actionPerformed(ActionEvent ae){
		if(ae.getSource()==conbtn){
			Login l1 = new Login();
			l1.setVisible(true);
			this.setVisible(false);
		}
		
		else if(ae.getSource()==exitbnt){
			System.exit(0);
		}
	}
	
}