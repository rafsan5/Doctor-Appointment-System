package FrameWork;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entities.*;

public class Registration extends JFrame implements MouseListener, ActionListener
{
	public JPanel panel;
	public Font myfont,myfont2,myfont3;
	public Color mycolor,regclr,bckclr;
	public JLabel title,rimglbl, namelbl,passlbl,namelbl2,doblbl,gndrlbl,emllbl,passlbl2,rpasslbl,usrnmlbl,sqlbl,sqalbl,caplbl;
	public JTextField namefld,namefld2,dobfld,emlfld,usrnmfld,capfld;
	public JPasswordField passfld,rpassfld;
	public JRadioButton m,f;
	public JButton regbtn,bckbtn;
	
	public ImageIcon rimg;
	
	public Registration(){
		super("Doctor's appointment system - Registration window");
		this.setSize(1020,620);
		this.setLocation(130,30);
		this.setResizable(false);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		regclr = new Color(79,207,68);
		bckclr = new Color(209,48,48);
		mycolor = new Color(221,224,217);
		
		myfont = new Font("Times New Roman", Font.PLAIN, 20);
		myfont2= new Font("Century Gothic", Font.BOLD, 30);
		myfont3= new Font("Century Gothic", Font.PLAIN,12);
		
		
		rimg = new ImageIcon("./Images/rgstr.jpg");
		panel.setBackground(mycolor);
		
		
		title=new JLabel("REGISTER AS PATIENT");
		title.setBounds(150,20,400,35);
		title.setFont(myfont2);
		panel.add(title);
		
		namelbl=new JLabel("First Name:");
		namelbl.setBounds(50,100,150,40);
		namelbl.setFont(myfont);
		panel.add(namelbl);
		
		namefld=new JTextField();
		namefld.setBounds(150,100,150,40);
		panel.add(namefld);
		
		namelbl2 = new JLabel("Last Name:");
		namelbl2.setBounds(330,100,150,40);
		namelbl2.setFont(myfont);
		panel.add(namelbl2);
		
		namefld2=new JTextField();
		namefld2.setBounds(430,100,150,40);
		panel.add(namefld2);
		
		doblbl = new JLabel("Enter DOB(dd/mm/yyyy) format:");
		doblbl.setBounds(50,150,460,40);
		doblbl.setFont(myfont);
		panel.add(doblbl);
		
		dobfld=new JTextField();
		dobfld.setBounds(430,150,150,40);
		panel.add(dobfld);
		
		gndrlbl = new JLabel("Select Gender:");
		gndrlbl.setBounds(50,200,200,40);
		gndrlbl.setFont(myfont);
		panel.add(gndrlbl);
		
		m = new JRadioButton("Male");
        m.setBounds(250,200,100,40);
        m.setFont(myfont);
		m.setBackground(null);
		panel.add(m);
		
		f = new JRadioButton("Female");
        f.setBounds(450,200,150,40);
        f.setFont(myfont);
		f.setBackground(null);
		panel.add(f);
		

		emllbl = new JLabel("Enter Email:");
		emllbl.setBounds(50,250,200,40);
		emllbl.setFont(myfont);
		panel.add(emllbl);
		
		emlfld=new JTextField();
		emlfld.setBounds(200,250,200,40);
		panel.add(emlfld);
		
		usrnmlbl = new JLabel("Username:");
		usrnmlbl.setBounds(50,300,250,40);
		usrnmlbl.setFont(myfont);
		panel.add(usrnmlbl);
		
		usrnmfld=new JTextField();
		usrnmfld.setBounds(200,300,200,40);
		panel.add(usrnmfld);
		
		passlbl=new JLabel("Password:");
		passlbl.setBounds(50,350,180,40);
		passlbl.setFont(myfont);
		panel.add(passlbl);
		
		passfld=new JPasswordField();
		passfld.setBounds(200,350,200,40);
		passfld.setEchoChar('*');
		panel.add(passfld);
		
		passlbl2=new JLabel("(Must be at least 8 characters)");
		passlbl2.setBounds(400,350,330,40);
		passlbl2.setFont(myfont3);
		panel.add(passlbl2);
		
		rpasslbl=new JLabel("Re-Type Password:");
		rpasslbl.setBounds(50,400,220,40);
		rpasslbl.setFont(myfont);
		panel.add(rpasslbl);
		
		rpassfld=new JPasswordField();
		rpassfld.setBounds(270,400,200,40);
		rpassfld.setEchoChar('*');
		panel.add(rpassfld);
		
		caplbl=new JLabel("Captcha:   4+3=?");
		caplbl.setBounds(50,450,300,40);
		caplbl.setFont(myfont);
		panel.add(caplbl);
		
		capfld=new JTextField();
		capfld.setBounds(270,450,200,40);
		panel.add(capfld);
		
		
		regbtn=new JButton("REGISTER");
		regbtn.setBounds(50,500,200,40);
		regbtn.setBackground(regclr);
		regbtn.setFont(myfont);
		regbtn.setForeground(Color.WHITE);
		regbtn.addMouseListener(this);
		regbtn.addActionListener(this);
		panel.add(regbtn);
		
		
		bckbtn=new JButton("BACK");
		bckbtn.setBounds(420,500,150,40);
		bckbtn.setBackground(bckclr);
		bckbtn.setFont(myfont);
		bckbtn.setForeground(Color.WHITE);
		bckbtn.addMouseListener(this);
		bckbtn.addActionListener(this);
		panel.add(bckbtn);
		
		
		
		rimglbl=new JLabel(rimg);
		rimglbl.setBounds(600,0,900,700);
		panel.add(rimglbl);
		
		this.add(panel);
		
		
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	
	public void actionPerformed(ActionEvent ae)
	{
		String sgender = "";
        if (m.isSelected()) {
        sgender = "Male";
		} 
		else if (f.isSelected()) {
        sgender = "Female";
		}
		
		String fname = namefld.getText();
		String lname = namefld2.getText();
		String dob = dobfld.getText();
		String gender = sgender;
		String cap = capfld.getText();
		String email = emlfld.getText();
		String username = usrnmfld.getText();
	 	String password = new String(passfld.getPassword());
        String rpassword = new String(rpassfld.getPassword());;
		
	    if(ae.getSource()==regbtn){
			
			if(fname.isEmpty()|| fname.isEmpty()|| lname.isEmpty()|| dob.isEmpty()|| gender.isEmpty()|| cap.isEmpty()|| email.isEmpty()|| username.isEmpty()|| password.isEmpty()|| rpassword.isEmpty())
			{
				JOptionPane.showMessageDialog(this,"Fill Up All");
			}
			
			
			else if(password.length()<=7){
				JOptionPane.showMessageDialog(this,"Password must be at least 8 characters");
				passfld.setText("");
			}
			
			else if (!password.equals(rpassword)) {
            JOptionPane.showMessageDialog(this, "Password and Re-Type Password Did not Match!");
            passfld.setText("");
            rpassfld.setText("");
			}
			
			else if(!cap.equals("7")){
				JOptionPane.showMessageDialog(this,"Incorrect Captcha");
				capfld.setText("");
			}
			
			else{
				JOptionPane.showMessageDialog(this,"Registered");
				
				Account a2 = new Account(username,password,rpassword,fname,lname,dob,gender,cap,email);
				a2.addUser();
				
				
				Login l1 = new Login();
				l1.setVisible(true);
				this.setVisible(false);
				
				passfld.setText("");
				rpassfld.setText("");
			}
			
			
			
		}
		else if(ae.getSource()==bckbtn)
		{
			Login l2 = new Login();
			l2.setVisible(true);
			this.setVisible(false);
		}
}
}