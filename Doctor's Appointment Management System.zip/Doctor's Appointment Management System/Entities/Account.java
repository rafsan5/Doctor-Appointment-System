package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import java.nio.file.*;
import FrameWork.*;

public class Account{
	
	
		
		private String username;
		private String password;
		private String rpassword;
		private String fname;
		private String lname;
		private String dob;
		private String gender;
		private String cap;
		private String email;
		
		
	
	public File file;
	public FileWriter fwriter;
	
	Scanner sc;
	
	public Account(){
		
	}
	
	public Account(String username,String password,String rpassword,String fname,String lname,String dob,String gender,String email,String cap){
		this.username = username;
		this.password = password;
		this.rpassword = rpassword;
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.gender= gender;
		this.cap = cap;
		this.email = email;
		
		
	}
	
	public void setUsername(String username){
		this.username = username;
	}
	
	public String getUsername(){
		return username;
	}
	
	public void setPassword(String password){
		this.password = password;
	}
	
	public String getPassword(){
		return password;
	}
	
	public void setRpassword(String rpassword){
		this.rpassword = rpassword;
	}
	
	public String getRpassword(){
		return rpassword;
	}
	
	public void setFname(String fname){
		this.fname = fname;
	}
	
	public String getFname(){
		return fname;
	}
	
	public void setLname(String lname){
		this.lname = lname;
	}
	
	public String getLname(){
		return lname;
	}
	
	public void setDOB(String dob){
		this.dob = dob;
	}
	
	public String getDOB(){
		return dob;
	}
	
	public void setCap(String cap){
		this.cap = cap;
	}
	
	public String getCap(){
		return cap;
	}
	
	public void setEmail(String email){
		this.email = email;
	}
	
	public String getEmail(){
		return email;
	}
	
	public void setGender(String gender){
		this.gender = gender;
	}
	
	public String getGender(){
		return gender;
	}
	
	public void addUser(){
		try
		{
			
		file = new File("./Datas/Data.txt");
		file.createNewFile();
		
		fwriter = new FileWriter(file,true);
		fwriter.write(getUsername()+",");
		fwriter.write(getPassword()+",");
		fwriter.write(getRpassword()+",");
		fwriter.write(getCap()+",");
		fwriter.write(getFname()+",");
		fwriter.write(getLname()+",");
		fwriter.write(getDOB()+",");
		fwriter.write(getGender()+",");
		fwriter.write(getEmail()+",\n");
		
		fwriter.flush();
		fwriter.close();
		
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public boolean checkLogin(String username,String password)
	{
		boolean flag=false;
		file=new File("./Datas/Data.txt");
		try
		{
			sc=new Scanner(file);
			
			while(sc.hasNextLine())
			{
				String line=sc.nextLine();
				String[] value=line.split(",");
				if(value[0].equals(username)&&value[1].equals(password))
				{
					flag=true;
				}
			}
			
			
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		return flag;
	}
	
	
}